<?php
include_once('connection.php');
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/all.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <title>View Book</title>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10 ml-auto mr-auto">
                <div class="card ml-auto mr-auto mt-3 shadow-lg p-1 mb-3 bg-white rounded">
                    <!-- <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="image/slider1.jpg" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="image/slider2.jpg" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="image/slider3.jpg" class="d-block w-100" alt="...">
                            </div>
                        </div>
                    </div> -->
                    <?php
                    global $error;
                    if (isset($_POST['submitDeleteButton'])) {
                        $key = $_POST['keyToDelete'];
                        //check if the record is exist or not
                        $check = mysqli_query($connection, "SELECT * FROM `book` WHERE id = '$key' ");
                        $count = mysqli_num_rows($check);

                        if ($count > 0) {
                            $delete = mysqli_query($connection, "DELETE FROM `book` WHERE id = '$key' ");
                            echo "Book Successfully Delete";
                        }
                    }
                    ?>
                    <img src="image/book_banner.jpg" class="card-img-top shadow-lg p-1 mb-1 bg-dark rounded" alt=" book">
                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">Book ID</th>
                                    <th scope="col">Book Name</th>
                                    <th scope="col">Book Published Date</th>
                                    <th scope="col">Book Price</th>
                                    <th scope="col">Book Details</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <?php
                                    $query = "SELECT *FROM book";
                                    $user_set = mysqli_query($connection, $query);
                                    ?>
                                    <?php
                                    while ($users = mysqli_fetch_assoc($user_set)) {
                                    ?>
                                        <form method="POST">
                                            <td><?php echo ($users["book_id"]); ?></td>
                                            <td><?php echo ($users["book_name"]); ?></td>
                                            <td><?php echo ($users["publish_date"]); ?></td>
                                            <td><?php echo ($users["book_price"]); ?></td>
                                            <td><?php echo ($users["book_details"]); ?></td>
                                            <td>
                                                <input type="hidden" name="keyToDelete" value="<?php echo $users['id'] ?>">
                                                &nbsp;&nbsp;&nbsp;
                                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" name="viewBook">Edit</button>
                                                <input type="submit" onclick="if (!confirm('Are you sure you wants to delete Book?')) { return false }" name="submitDeleteButton" class="btn btn-danger" value="Delete">

                                            </td>
                                        </form>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Button trigger modal -->

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Update Book Information</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <div class="form-row">
                            <?php
                            global $error;
                            if (isset($_POST['submitDeleteButton'])) {
                                $key = $_POST['keyToDelete'];
                                //check if the record is exist or not
                                $query = "SELECT *FROM book where id = $key";
                                    $user_set = mysqli_query($connection, $query);
                                    ?>
                                    <?php
                                    while ($users = mysqli_fetch_assoc($user_set)) {

                                    $book_id = $users["book_id"];
                                    echo $book_id;
                                    // $lname = $users["l_name"];
                                    // $email = $users["email"];
                                    // $phone = $users["phone"];
                                    // $addr1 = $users["address_line1"];
                                    // $addr2 = $users["address_line2"];
                                    // $city = $users["city"];
                                    // $state = $users["state"];
                                    // $country = $users["country"];
                                    // $pcode = $users["postal_code"];
                                }
                            } ?>
                            <div class="form-group col-md-3">
                                <label for="inputEmail4">Book ID</label>
                                <input type="text" class="form-control" name="book_id" value="<?php echo $book_id; ?>">
                            </div>
                            <div class="form-group col-md-9">
                                <label for="inputPassword4">Book Title</label>
                                <input type="text" class="form-control" name=" book_title" value="<?php echo ($users["book_name"]); ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputEmail4">Book Published Date</label>
                                <input type="date" class="form-control" name="book_published_date" value="<?php echo ($users["publish_date"]); ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputPassword4">Book Price</label>
                                <input type="text" class="form-control" name=" book_price" value="<?php echo ($users["book_price"]); ?>">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleFormControlTextarea1">Book Detail</label>
                                <textarea class="form-control" name="book_details" rows="3"> <?php echo ($books["book_details"]); ?></textarea>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="if (!confirm('Are you sure you wants to save the change?')) { return false }" data-dismiss="modal">Save changes</button>
                </div>
            </div>
        </div>
    </div>
    <script src="js/jquery-3.4.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>

</html>