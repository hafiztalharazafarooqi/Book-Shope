<?php
include_once('connection.php');
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/all.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <title>Add Book</title>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 ml-auto mr-auto">
                <div class="card ml-auto mr-auto mt-3 shadow-lg p-1 mb-3 bg-white rounded">
                    <div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="image/slider1.jpg" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="image/slider2.jpg" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="image/slider3.jpg" class="d-block w-100" alt="...">
                            </div>
                        </div>
                    </div>
                    <!-- <img src="image/book_banner.jpg" class="card-img-top shadow-lg p-1 mb-1 bg-dark rounded" alt=" book"> -->
                    <div class="card-body">
                        <form method="POST">
                            <div class="form-row">
                                <div class="form-group col-md-3">
                                    <label for="inputEmail4">Book ID</label>
                                    <input type="text" class="form-control" name="book_id">
                                </div>
                                <div class="form-group col-md-9">
                                    <label for="inputPassword4">Book Title</label>
                                    <input type="text" class="form-control" name=" book_title">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="inputEmail4">Book Published Date</label>
                                    <input type="date" class="form-control" name="book_published_date">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="inputPassword4">Book Price</label>
                                    <input type="text" class="form-control" name=" book_price">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="exampleFormControlTextarea1">Book Detail</label>
                                    <textarea class="form-control" name="book_details" rows="3"></textarea>
                                </div>
                            </div>
                            <center>
                                <button type="submit" name="add_book" class="btn btn-primary  col-md-6 ml-auto mr-auto">Add Book</button>
                            </center>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    global $error;
    global $success;
    if (isset($_POST['add_book'])) {

        // Process the form
        $book_id = mysqli_real_escape_string($connection, $_POST['book_id']);
        $book_title = mysqli_real_escape_string($connection, $_POST['book_title']);
        $book_published_date = mysqli_real_escape_string($connection, $_POST['book_published_date']);
        $book_price = mysqli_real_escape_string($connection, $_POST['book_price']);
        $book_details = mysqli_real_escape_string($connection, $_POST['book_details']);

        // Insert Book Query
        $sql = "INSERT INTO `book`(`book_id`, `book_name`, `book_details`, `publish_date`, `book_price`) 
        VALUES ('$book_id','$book_title','$book_details','$book_published_date','$book_price')";

        // Check book inserted or not
        if (mysqli_query($connection, $sql)) {
            echo "New book added successfully";
        } else {
            echo "<hr> <br>Error: " . $sql . "<br>" . mysqli_error($connection);
        }
    }
    ?>
    <script src="js/jquery-3.4.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>

</html>